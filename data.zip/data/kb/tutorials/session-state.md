---
title: Session State basics
slug: /knowledge-base/tutorials/session-state
---

# Session State basics

Check out this Session State basics tutorial video by Streamlit Developer Advocate Dr. Marisa Smith to get started:

<YouTube videoId="92jUAXBmZyU" />
