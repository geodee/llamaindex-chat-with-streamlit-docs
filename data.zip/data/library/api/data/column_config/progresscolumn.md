---
title: st.column_config.ProgressColumn
slug: /library/api-reference/data/st.column_config/st.column_config.progresscolumn
---

<Autofunction function="streamlit.column_config.ProgressColumn" />
