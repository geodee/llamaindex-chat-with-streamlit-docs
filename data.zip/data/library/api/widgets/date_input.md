---
title: st.date_input
slug: /library/api-reference/widgets/st.date_input
description: st.date_input displays a date input widget.
---

<Autofunction function="streamlit.date_input" />
