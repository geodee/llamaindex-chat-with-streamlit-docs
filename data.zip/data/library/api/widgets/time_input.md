---
title: st.time_input
slug: /library/api-reference/widgets/st.time_input
description: st.time_input displays a time input widget.
---

<Autofunction function="streamlit.time_input" />
