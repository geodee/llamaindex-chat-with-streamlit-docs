---
title: st.caption
slug: /library/api-reference/text/st.caption
description: st.caption displays text in small font.
---

<Autofunction function="streamlit.caption" />

<Image src="/images/api/st.caption.png" clean />
