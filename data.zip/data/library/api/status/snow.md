---
title: st.snow
slug: /library/api-reference/status/st.snow
description: st.snow displays celebratory snowflakes!
---

<Autofunction function="streamlit.snow" />
