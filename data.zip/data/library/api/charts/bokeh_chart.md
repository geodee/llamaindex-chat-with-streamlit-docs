---
title: st.bokeh_chart
slug: /library/api-reference/charts/st.bokeh_chart
description: st.bokeh_chart displays an interactive Bokeh chart.
---

<Autofunction function="streamlit.bokeh_chart" />
