---
title: st.bar_chart
slug: /library/api-reference/charts/st.bar_chart
description: st.bar_chart displays a bar chart.
---

<Autofunction function="streamlit.bar_chart" />
