---
title: st.pyplot
slug: /library/api-reference/charts/st.pyplot
description: st.pyplot displays a matplotlib.pyplot figure.
---

<Autofunction function="streamlit.pyplot" />
