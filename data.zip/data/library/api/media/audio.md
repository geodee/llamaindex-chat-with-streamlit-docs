---
title: st.audio
slug: /library/api-reference/media/st.audio
description: st.audio displays an audio player.
---

<Autofunction function="streamlit.audio" />
