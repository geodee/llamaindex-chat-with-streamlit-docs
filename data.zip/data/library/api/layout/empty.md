---
title: st.empty
slug: /library/api-reference/layout/st.empty
description: st.empty inserts a single-element container.
---

<Autofunction function="streamlit.empty" />
