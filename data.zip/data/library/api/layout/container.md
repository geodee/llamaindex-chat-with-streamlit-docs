---
title: st.container
slug: /library/api-reference/layout/st.container
description: st.container inserts a multi-element container.
---

<Autofunction function="streamlit.container" />
